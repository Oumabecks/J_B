<?php

namespace Models;

use Models\Item;

class Cart
{
    private $items = [];

    public function addItem(Product $product, $quantity)
    {
        $this->items[] = new Item($product, $quantity);
    }

    public function getItems()
    {
        return $this->items;
    }

    public function getTotal()
    {
        $total = 0;
        foreach ($this->items as $item) {
            $total += $item->getTotalPrice();
        }
        return $total;
    }
}
