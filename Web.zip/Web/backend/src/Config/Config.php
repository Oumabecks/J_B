<?php

// Configuration settings like DB credentials, API keys, etc.
define('DB_HOST', 'localhost');
define('DB_NAME', 'myapp');
define('DB_USER', 'user');
define('DB_PASS', '');
