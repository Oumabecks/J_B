
<?php
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\Type;

$ProductType = new ObjectType([
    'name' => 'Product',
    'fields' => [
        'id' => Type::nonNull(Type::int()),
        'name' => Type::string(),
        'price' => Type::float(),
        'category' => Type::string(),
        // Add other fields as needed
    ],
]);
