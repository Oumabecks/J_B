<?php

require_once 'C:/xampp/htdocs/J/vendor/autoload.php';
use GraphQL\Type\Definition\Type;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Schema;
use GraphQL\GraphQL;

// Define the AttributeItem type
$AttributeItemType = new ObjectType([
    'name' => 'AttributeItem',
    'fields' => [
        'displayValue' => Type::string(),
        'value' => Type::string(),
        'id' => Type::string(),
        '__typename' => Type::string(),
    ],
]);

// Define the Attribute type
$AttributeType = new ObjectType([
    'name' => 'Attribute',
    'fields' => [
        'id' => Type::nonNull(Type::string()),
        'name' => Type::string(),
        'type' => Type::string(),
        'items' => Type::listOf($AttributeItemType),
        '__typename' => Type::string(),
    ],
]);

// Define the Gallery type
$GalleryType = new ObjectType([
    'name' => 'Gallery',
    'fields' => [
        'image__001' => Type::string(),
        'image__002' => Type::string(),
        'image__003' => Type::string(),
        'image__004' => Type::string(),
        'image__005' => Type::string(),
        'image__006' => Type::string(),
        'image__007' => Type::string(),
    ],
]);

// Define the Currency type
$CurrencyType = new ObjectType([
    'name' => 'Currency',
    'fields' => [
        'label' => Type::string(),
        'symbol' => Type::string(),
        '__typename' => Type::string(),
    ],
]);

// Define the Price type
$PriceType = new ObjectType([
    'name' => 'Price',
    'fields' => [
        'amount' => Type::float(),
        'currency' => $CurrencyType,
        '__typename' => Type::string(),
    ],
]);

// Define the Product type
$ProductType = new ObjectType([
    'name' => 'Product',
    'fields' => [
        'id' => Type::nonNull(Type::string()),
        'name' => Type::string(),
        'inStock' => Type::boolean(),
        'gallery' => $GalleryType,
        'description' => Type::string(),
        'category' => Type::string(),
        'attributes' => Type::listOf($AttributeType),
        'prices' => Type::listOf($PriceType),
        'brand' => Type::string(),
        '__typename' => Type::string(),
    ],
]);

// Define the Category type
$CategoryType = new ObjectType([
    'name' => 'Category',
    'fields' => [
        'name' => Type::string(),
        '__typename' => Type::string(),
        'products' => Type::listOf($ProductType),
    ],
]);

// Define the Query type
$QueryType = new ObjectType([
    'name' => 'Query',
    'fields' => [
        'categories' => [
            'type' => Type::listOf($CategoryType),
            'resolve' => function ($root, $args) {
                try {
                    $connection = Database::getInstance();
                    if (!$connection) {
                        throw new Exception('Database connection failed');
                    }

                    $stmt = $connection->prepare("
                        
    SELECT 
    c.categories__name,
    c.categories_____typename,
    p.products__id,
    p.products__name,
    p.products__inStock,
    p.products__gallery__001,
    p.products__description,
    p.products__category,
    p.products__attributes__id,
    p.products__brand,
    p.products_____typename,
    g.products__gallery__001,
    g.products__gallery__002,
    g.products__gallery__003,
    g.products__gallery__004,
    g.products__gallery__005,
    g.products__gallery__006,
    g.products__gallery__007,
    a.products__attributes__id,
    a.products__attributes__items__id,
    a.products__attributes__name,
    a.products__attributes__type,
    a.products__attributes_____typename,
    i.products__attributes__items__displayValue,
    i.products__attributes__items__value,
    i.products__attributes__items__id,
    i.products__attributes__items_____typename,
    pr.products__prices__amount,
    pr.products__prices__currency__label,
    pr.products__prices_____typename,
    cu.products__prices__currency__label,
    cu.products__prices__currency__symbol,
    cu.products__prices__currency_____typename
FROM 
    products p
LEFT JOIN 
    gallery g ON p.products__gallery__001 = g.products__gallery__001
LEFT JOIN 
    attributes a ON p.products__attributes__id = a.products__attributes__id
LEFT JOIN 
    items i ON a.products__attributes__items__id = i.products__attributes__items__id
LEFT JOIN 
    prices pr ON p.products__prices__amount = pr.products__prices__amount
LEFT JOIN 
    currency cu ON pr.products__prices__currency__label = cu.products__prices__currency__label
LEFT JOIN 
    categories c ON p.products__category = c.categories__name;

                    ");
                    $stmt->execute();
                    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if (!$rows) {
                        throw new Exception('No data found');
                    }

                    $categories = [];
                    foreach ($rows as $row) {
                        $categoryName = $row['category__name'];
                        if (!isset($categories[$categoryName])) {
                            $categories[$categoryName] = [
                                'name' => $categoryName,
                                'products' => [],
                            ];
                        }

                        $categories[$categoryName]['products'][] = [
                            'id' => $row['product__id'],
                            'name' => $row['product__name'],
                            'inStock' => (bool)$row['product__inStock'],
                            'gallery' => [
                                'image__001' => $row['image__001'],
                                'image__002' => $row['image__002'],
                                'image__003' => $row['image__003'],
                                'image__004' => $row['image__004'],
                                'image__005' => $row['image__005'],
                                'image__006' => $row['image__006'],
                                'image__007' => $row['image__007'],
                            ],
                            'description' => $row['description'],
                            'category' => $row['category'],
                            'attributes' => [
                                [
                                    'id' => $row['attribute__id'],
                                    'name' => $row['attribute__name'],
                                    'type' => $row['attribute__type'],
                                    'items' => [
                                        [
                                            'displayValue' => $row['attribute__item__displayValue'],
                                            'value' => $row['attribute__item__value'],
                                            'id' => $row['attribute__item__id'],
                                            '__typename' => 'AttributeItem',
                                        ],
                                    ],
                                    '__typename' => 'Attribute',
                                ],
                            ],
                            'prices' => [
                                [
                                    'amount' => (float)$row['price__amount'],
                                    'currency' => [
                                        'label' => $row['currency__label'],
                                        'symbol' => $row['currency__symbol'],
                                        '__typename' => 'Currency',
                                    ],
                                    '__typename' => 'Price',
                                ],
                            ],
                            'brand' => $row['product__brand'],
                            '__typename' => 'Product',
                        ];
                    }

                    return array_values($categories);
                } catch (Exception $e) {
                    error_log("Error in GraphQL resolve: " . $e->getMessage());
                    return ['error' => 'An error occurred: ' . $e->getMessage()];
                }
            },
        ],
    ],
]);

// Create the GraphQL schema
$schema = new Schema([
    'query' => $QueryType,
]);

// Handle the GraphQL request
$input = file_get_contents('C:\Users\jessy\Desktop\data.json');
$inputData = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['errors' => [['message' => 'Invalid JSON format: ' . json_last_error_msg()]]]);
    exit;
}

error_log("Received JSON: " . print_r($inputData, true));  // Log received data
file_put_contents('php://stderr', print_r($_SERVER, true));  // Log server variables
file_put_contents('php://stderr', file_get_contents('C:\Users\jessy\Desktop\data.json'));  // Log raw input

// Add CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Use the provided GraphQL query if available
$providedQuery = '{ categories { name __typename products { id name inStock gallery { image001 image002 image003 image004 image005 image006 image007 } description category attributes { id items { displayValue value id __typename } name type __typename } prices { amount currency { label symbol __typename } __typename } brand __typename } } }';

$query = $inputData['query'] ?? $providedQuery;

// Execute the GraphQL query
try {
    $result = GraphQL::executeQuery(
        $schema,
        $query,
        null,
        null,
        $inputData['variables'] ?? null
    );
    $output = $result->toArray();
} catch (\Exception $e) {
    error_log("Error executing GraphQL query: " . $e->getMessage());
    $output = [
        'errors' => [
            ['message' => 'Internal server error: ' . $e->getMessage(), 'details' => $e->getTraceAsString()]
        ]
    ];
}

// Send the response
echo json_encode($output);
