<?php
namespace Controllers;

// Corrected path to autoload.php
require_once 'C:/xampp/htdocs/J/Vendor/autoload.php';

use Core\Controller;
use Models\Cart;
use Models\Product;

class CartController extends Controller
{
    private $cart;

    public function __construct(Cart $cart)
    {
        $this->cart = $cart;
    }

    public function index()
    {
        $items = $this->cart->getItems();
        $total = $this->cart->getTotal();
        $this->render('cart_overlay', ['items' => $items, 'total' => $total]);
    }

    public function add()
    {
        // Sanitize input data
        $productId = filter_input(INPUT_POST, 'product_id', FILTER_SANITIZE_NUMBER_INT);
        $quantity = filter_input(INPUT_POST, 'quantity', FILTER_SANITIZE_NUMBER_INT);

        if ($productId && $quantity) {
            $product = Product::find($productId);
            if ($product) {
                $this->cart->addItem($product, $quantity);
            } else {
                // Handle the case where the product is not found
                $this->render('error', ['message' => 'Product not found.']);
                return;
            }
        } else {
            // Handle invalid input
            $this->render('error', ['message' => 'Invalid product ID or quantity.']);
            return;
        }
        
        $this->index(); // Re-render cart view
    }

    public function checkout()
    {
        // Process the order
        try {
            // Assume order processing logic here

            // Reset cart after successful checkout
            $this->cart = new Cart();
            $this->render('checkout_success');
        } catch (\Exception $e) {
            // Handle exceptions (e.g., logging, error display)
            $this->render('error', ['message' => 'Checkout failed.']);
        }
    }
}
