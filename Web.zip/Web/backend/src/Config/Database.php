<?php

namespace Src\Config;

use PDO;
use PDOException;

class Database
{
    private static $instance = null;
    private $connection;

    // Public constructor to allow direct instantiation
    public function __construct()
    {
        try {
            $this->connection = new PDO('mysql:host=localhost;dbname=jessy_db', 'root', '');
            // Set error mode to exception
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
            exit; // Exit if the connection fails
        }
    }

    // Public static method to get the singleton instance
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    // Public method to get the connection
    public function getConnection()
    {
        return $this->connection;
    }
}
