<?php
namespace Src\GraphQL\Resolvers;

use Src\Config\Database;

class ProductResolver {
    private $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function resolve() {
        try {
            // Prepare SQL query to fetch all products
            $stmt = $this->connection->prepare("SELECT * FROM products");
            $stmt->execute();
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (!$products) {
                throw new Exception('No products found');
            }

            return $products;

        } catch (Exception $e) {
            return ['error' => 'An error occurred: ' . $e->getMessage()];
        }
    }
}
