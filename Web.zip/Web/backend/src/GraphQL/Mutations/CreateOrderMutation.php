<?php
namespace Src\GraphQL\Mutations;

class CreateOrderMutation {
    private $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function resolve($args) {
        // Validate the input arguments (optional but recommended)
        if (!isset($args['user_id'], $args['product_id'], $args['quantity'])) {
            throw new \InvalidArgumentException('Missing required arguments');
        }

        // Insert the order and get the ID of the newly created order
        $orderId = $this->insertOrder($args);

        // Return a response indicating success
        return [
            'id' => $orderId, 
            'status' => 'Order created successfully'
        ];
    }

    private function insertOrder($args) {
        // Prepare the SQL statement to insert an order
        $stmt = $this->connection->prepare("
            INSERT INTO orders (user_id, product_id, quantity) 
            VALUES (:user_id, :product_id, :quantity)
        ");

        // Bind the parameters to the SQL statement
        $stmt->bindParam(':user_id', $args['user_id'], \PDO::PARAM_INT);
        $stmt->bindParam(':product_id', $args['product_id'], \PDO::PARAM_INT);
        $stmt->bindParam(':quantity', $args['quantity'], \PDO::PARAM_INT);

        // Execute the statement
        $stmt->execute();

        // Return the ID of the newly created order
        return $this->connection->lastInsertId();
    }
}
