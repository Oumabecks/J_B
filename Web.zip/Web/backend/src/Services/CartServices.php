<?php

namespace Services;

use Models\Cart;
use Models\Product;

class CartService
{
    private $cart;

    public function __construct(Cart $cart)
    {
        $this->cart = $cart;
    }

    public function addProductToCart($productId, $quantity)
    {
        $product = Product::find($productId);
        if ($product) {
            $this->cart->addItem($product, $quantity);
        }
    }

    public function calculateTotal()
    {
        return $this->cart->getTotal();
    }
}
