<?php

// Display errors for debugging (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include Composer autoload file
require_once 'C:\xampp\htdocs\J\vendor\autoload.php';

use GraphQL\Type\Definition\Type;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Schema;
use GraphQL\GraphQL;
use Src\Config\Database;

// Define the AttributeItem type
$AttributeItemType = new ObjectType([
    'name' => 'AttributeItem',
    'fields' => [
        'displayValue' => Type::string(),
        'value' => Type::string(),
        'id' => Type::string(),
    ],
]);

// Define the Attribute type
$AttributeType = new ObjectType([
    'name' => 'Attribute',
    'fields' => [
        'id' => Type::nonNull(Type::string()),
        'name' => Type::string(),
        'type' => Type::string(),
        'items' => Type::listOf($AttributeItemType),
    ],
]);

// Define the Gallery type
$GalleryType = new ObjectType([
    'name' => 'Gallery',
    'fields' => [
        'image001' => Type::string(),
        'image002' => Type::string(),
        'image003' => Type::string(),
        'image004' => Type::string(),
        'image005' => Type::string(),
        'image006' => Type::string(),
        'image007' => Type::string(),
    ],
]);

// Define the Currency type
$CurrencyType = new ObjectType([
    'name' => 'Currency',
    'fields' => [
        'label' => Type::string(),
        'symbol' => Type::string(),
    ],
]);

// Define the Price type
$PriceType = new ObjectType([
    'name' => 'Price',
    'fields' => [
        'amount' => Type::float(),
        'currency' => $CurrencyType,
    ],
]);

// Define the Product type
$ProductType = new ObjectType([
    'name' => 'Product',
    'fields' => [
        'id' => Type::nonNull(Type::string()),
        'name' => Type::string(),
        'inStock' => Type::boolean(),
        'gallery' => $GalleryType,
        'description' => Type::string(),
        'category' => Type::string(),
        'attributes' => Type::listOf($AttributeType),
        'prices' => Type::listOf($PriceType),
        'brand' => Type::string(),
    ],
]);

// Define the Category type
$CategoryType = new ObjectType([
    'name' => 'Category',
    'fields' => [
        'name' => Type::string(),
        'products' => Type::listOf($ProductType),
    ],
]);

// Define the Query type
$QueryType = new ObjectType([
    'name' => 'Query',
    'fields' => [
        'categories' => [
            'type' => Type::listOf($CategoryType),
            'resolve' => function ($root, $args) {
                try {
                    // Establishing database connection
                    $connection = Database::getInstance();
                    if (!$connection) {
                        throw new Exception('Database connection failed');
                    }

                    // Prepare and execute SQL query
                    $stmt = $connection->prepare("
                        SELECT c.name as category_name, 
                               p.id as product_id, 
                               p.name as product_name, 
                               p.inStock, 
                               g.*, 
                               pr.amount as price_amount, 
                               cur.label as currency_label, 
                               cur.symbol as currency_symbol,
                               a.id as attribute_id, 
                               a.name as attribute_name, 
                               a.type as attribute_type,
                               ai.displayValue as attribute_item_displayValue, 
                               ai.value as attribute_item_value, 
                               ai.id as attribute_item_id,
                               p.brand as brand
                        FROM categories c
                        LEFT JOIN products p ON c.id = p.category
                        LEFT JOIN gallery g ON p.id = g.product_id
                        LEFT JOIN prices pr ON p.id = pr.product_id
                        LEFT JOIN currencies cur ON pr.currency_id = cur.id
                        LEFT JOIN attributes a ON p.id = a.product_id
                        LEFT JOIN attribute_items ai ON a.id = ai.attribute_id
                    ");
                    $stmt->execute();
                    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if (!$rows) {
                        throw new Exception('No data found');
                    }

                    // Ensure proper data structure in the GraphQL resolve function
$categories = [];
foreach ($rows as $row) {
    $categoryName = $row['category_name'];

    // Initialize category if not set
    if (!isset($categories[$categoryName])) {
        $categories[$categoryName] = [
            'name' => $categoryName,
            'products' => [],
        ];
    }

    // Initialize product data structure
    $product = [
        'id' => $row['product_id'],
        'name' => $row['product_name'],
        'inStock' => isset($row['inStock']) ? (bool)$row['inStock'] : false,
        'gallery' => [
            'image001' => $row['image001'] ?? null,
            'image002' => $row['image002'] ?? null,
            'image003' => $row['image003'] ?? null,
            'image004' => $row['image004'] ?? null,
            'image005' => $row['image005'] ?? null,
            'image006' => $row['image006'] ?? null,
            'image007' => $row['image007'] ?? null,
        ],
        'description' => $row['description'] ?? '',
        'category' => $row['category'] ?? '',
        'attributes' => [],
        'prices' => [],
        'brand' => $row['brand'] ?? '',
    ];

    // Add attributes to product
    if (!empty($row['attribute_id'])) {
        $product['attributes'][] = [
            'id' => $row['attribute_id'],
            'name' => $row['attribute_name'] ?? '',
            'type' => $row['attribute_type'] ?? '',
            'items' => [
                [
                    'displayValue' => $row['attribute_item_displayValue'] ?? '',
                    'value' => $row['attribute_item_value'] ?? '',
                    'id' => $row['attribute_item_id'] ?? '',
                ],
            ],
        ];
    }

    // Add prices to product
    if (!empty($row['price_amount'])) {
        $product['prices'][] = [
            'amount' => (float)$row['price_amount'],
            'currency' => [
                'label' => $row['currency_label'] ?? '',
                'symbol' => $row['currency_symbol'] ?? '',
            ],
        ];
    }

    // Add the product to the category
    $categories[$categoryName]['products'][] = $product;
}

// Return categories with proper structure
return array_values($categories);


                } catch (Exception $e) {
                    error_log('GraphQL Resolve Error: ' . $e->getMessage());
                    throw new \Exception('Internal Server Error');
                }
            },
        ],
    ],
]);

// Create the GraphQL schema
$schema = new Schema([
    'query' => $QueryType,
]);

// Handle the GraphQL request
$input = file_get_contents('C:\xampp\htdocs\J\query.json');
$inputData = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['errors' => [['message' => 'Invalid JSON format: ' . json_last_error_msg()]]]);
    exit;
}
// Add CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Execute the GraphQL query
try {
    $result = GraphQL::executeQuery(
        $schema,
        $inputData['query'] ?? '{ categories { name products { id name } } }',
        null,
        null,
        $inputData['variables'] ?? null
    );
    $output = $result->toArray();
} catch (\Exception $e) {
    error_log('GraphQL Execution Error: ' . $e->getMessage());
    $output = [
        'errors' => [
            ['message' => 'Internal server error: ' . $e->getMessage(), 'details' => $e->getTraceAsString()]
        ]
    ];
}
// Send the response
echo json_encode($output);

?> 
 