<?php

namespace Core;

class ViewRenderer
{
    public static function render($view, $data = [])
    {
        extract($data);
        $viewFile = __DIR__ . '/../../Views/' . $view . '.php';

        if (file_exists($viewFile)) {
            require $viewFile;
        } else {
            throw new \Exception("View not found: $view");
        }
    }
}
