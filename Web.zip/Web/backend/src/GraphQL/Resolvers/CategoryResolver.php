<?php
namespace Src\GraphQL\Resolvers;

use Src\Models\Category;

class CategoryResolver {
    private $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function resolve() {
        try {
            // Prepare SQL query to fetch categories and associated products
            $stmt = $this->connection->prepare("
                SELECT c.name as category_name, p.*, g.*, pr.*, a.*
                FROM categories c
                LEFT JOIN products p ON c.id = p.category
                LEFT JOIN gallery g ON p.id = g.id
                LEFT JOIN prices pr ON p.id = pr.id
                LEFT JOIN attributes a ON p.id = a.id
            ");
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (!$rows) {
                throw new Exception('No data found');
            }

            $categories = [];
            foreach ($rows as $row) {
                $categoryName = $row['category_name'];
                if (!isset($categories[$categoryName])) {
                    $categories[$categoryName] = [
                        'name' => $categoryName,
                        'products' => [],
                    ];
                }

                $categories[$categoryName]['products'][] = [
                    'id' => $row['id'],
                    'name' => $row['name'],
                    'inStock' => (bool)$row['inStock'],
                    'gallery' => [
                        'image001' => $row['image001'],
                        'image002' => $row['image002'],
                        'image003' => $row['image003'],
                        'image004' => $row['image004'],
                        'image005' => $row['image005'],
                        'image006' => $row['image006'],
                        'image007' => $row['image007'],
                    ],
                    'description' => $row['description'],
                    'category' => $row['category'],
                    'attributes' => [
                        [
                            'id' => $row['attribute_id'],
                            'name' => $row['attribute_name'],
                            'type' => $row['attribute_type'],
                            'items' => [
                                [
                                    'displayValue' => $row['attribute_item_displayValue'],
                                    'value' => $row['attribute_item_value'],
                                    'id' => $row['attribute_item_id'],
                                    '__typename' => 'AttributeItem',
                                ],
                            ],
                            '__typename' => 'Attribute',
                        ],
                    ],
                    'prices' => [
                        [
                            'amount' => (float)$row['price_amount'],
                            'currency' => [
                                'label' => $row['currency_label'],
                                'symbol' => $row['currency_symbol'],
                                '__typename' => 'Currency',
                            ],
                            '__typename' => 'Price',
                        ],
                    ],
                    'brand' => $row['brand'],
                    '__typename' => 'Product',
                ];
            }

            return array_values($categories);

        } catch (Exception $e) {
            return ['error' => 'An error occurred: ' . $e->getMessage()];
        }
    }
}
