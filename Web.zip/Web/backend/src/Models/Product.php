<?php

namespace Models;

class Product
{
    public $id;
    public $name;
    public $price;
    public $image;

    public function __construct($id, $name, $price, $image)
    {
        $this->id = $id;
        $this->name = $name;
        $this->price = $price;
        $this->image = $image;
    }

    public static function all()
    {
        // Fetch all products from database (static for simplicity)
        return [
            new Product(1, 'Product 1', 10.99, 'image1.jpg'),
            new Product(2, 'Product 2', 20.99, 'image2.jpg'),
        ];
    }
}
