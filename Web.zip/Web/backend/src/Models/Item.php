<?php

namespace Models;

class Item
{
    public $product;
    public $quantity;

    public function __construct(Product $product, $quantity)
    {
        $this->product = $product;
        $this->quantity = $quantity;
    }

    public function getTotalPrice()
    {
        return $this->product->price * $this->quantity;
    }
}
