<?php

namespace Controllers;

use Models\Product;

// Manually include the Core\Controller class if autoloading is not set up
require_once __DIR__ . '/../Core/Controller.php';

class ProductController extends \Core\Controller
{
    public function index()
    {
        try {
            $products = Product::all();
            if ($products === false) {
                // Handle failure to retrieve products
                $this->render('error', ['message' => 'Unable to retrieve products.']);
                return;
            }
            $this->render('product_list', ['products' => $products]);
        } catch (\Exception $e) {
            // Handle exceptions and render an error view
            $this->render('error', ['message' => 'An error occurred: ' . $e->getMessage()]);
        }
    }
}
