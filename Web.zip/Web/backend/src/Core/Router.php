<?php

namespace Core;

class Router
{
 private $routes = [];

 public function get($path, $action)
 {
     $this->routes['GET'][$path] = $action;
 }

 public function post($path, $action)
 {
     $this->routes['POST'][$path] = $action;
 }

 public function dispatch($uri)
 {
     // Default to GET if REQUEST_METHOD is not set
     $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

     // Normalize URI: Remove query string, trailing slashes, and the base path (`/J/public`)
     $uri = str_replace('/J/public', '', parse_url($uri, PHP_URL_PATH));
     $uri = rtrim($uri, '/') ?: '/';

     if (isset($this->routes[$method][$uri])) {
         list($controller, $method) = explode('@', $this->routes[$method][$uri]);

         // Add namespace for the controller
         $controller = "Controllers\\$controller";

         // Check if the controller class exists
         if (class_exists($controller)) {
             $controllerInstance = new $controller();

             // Check if the method exists in the controller
             if (method_exists($controllerInstance, $method)) {
                 $controllerInstance->$method();
             } else {
                 $this->sendNotFound("Method $method not found in controller $controller.");
             }
         } else {
             $this->sendNotFound("Controller class $controller not found.");
         }
     } else {
         $this->sendNotFound("Route $uri not defined for $method method.");
     }
 }

 public function view($view, $data = [])
 {
     extract($data);
     $viewFile = __DIR__ . '/../../Views/' . $view . '.php';

     if (file_exists($viewFile)) {
         require $viewFile;
     } else {
         throw new \Exception("View not found: $view");
     }
 }

 private function sendNotFound($message)
 {
     http_response_code(404);
     echo "404 Not Found: $message";
 }
}