<?php
require_once 'C:\xampp\htdocs\J\src\Config\Config.php';
require_once 'C:\xampp\htdocs\J\src\Core\Router.php';
require_once '../vendor/autoload.php'; // Adjust the path relative to the public directory


define('BASE_PATH', 'C:\xampp\htdocs\J\\'); // Define BASE_PATH correctly

use Core\Router;
use GraphQL\GraphQL;
use Src\GraphQL\Schema;

try {
    // Initialize the database connection
// Initialize the database connection
$database = Src\Config\Database::getInstance();
$connection = $database->getConnection();

    // Check if the request is for GraphQL
    if ($_SERVER['REQUEST_URI'] === '/graphql') {
        // Handle GraphQL request
        $schema = new Schema($database->getConnection());
        
        // Parse the request to extract the query
        $rawInput = file_get_contents('php://input');
        $input = json_decode($rawInput, true);
        $query = $input['query'];

        // Execute the query against the schema
        $result = GraphQL::executeQuery($schema->getSchema(), $query);
        $output = $result->toArray();

        header('Content-Type: application/json');
        echo json_encode($output);
        exit; // End the script to avoid further processing
    } else {
        // Handle standard HTTP routing

        // Initialize and register routes
        $router = new Router();

        // Define your routes
        $router->get('/', 'ProductController@index');
        $router->get('/cart', 'CartController@index');
        $router->post('/cart/add', 'CartController@add');
        $router->post('/cart/checkout', 'CartController@checkout');

        // Get the current request URI
        $requestUri = $_SERVER['REQUEST_URI'];

        // Remove BASE_PATH if necessary (correct for your project structure)
        $requestUri = str_replace('http://localhost/J/', '', $requestUri);

        // Start routing
        $router->dispatch($requestUri); // Dispatch the request
    }
} catch (\Exception $e) {
    // Handle any exceptions
    $output = [
        'errors' => [
            [
                'message' => $e->getMessage()
            ]
        ]
    ];

    header('Content-Type: application/json');
    echo json_encode($output);
}
