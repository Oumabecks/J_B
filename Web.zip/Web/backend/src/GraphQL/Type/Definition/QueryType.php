<?php
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\Type;
use Src\GraphQL\Resolvers\CategoryResolver;
use Src\GraphQL\Resolvers\ProductResolver;

// Assuming you have an instance of Database or connection
$database = new Database();
$connection = $database->getConnection();

$QueryType = new ObjectType([
    'name' => 'Query',
    'fields' => [
        'categories' => [
            'type' => Type::listOf($CategoryType),
            'resolve' => function($root, $args) use ($connection) {
                $resolver = new CategoryResolver($connection);
                return $resolver->resolve();
            }
        ],
        'products' => [
            'type' => Type::listOf($ProductType),
            'resolve' => function($root, $args) use ($connection) {
                $resolver = new ProductResolver($connection);
                return $resolver->resolve();
            }
        ],
        // Add other queries as needed
    ],
]);
