<?php

namespace Core;

 class Controller
{
    protected function render($view, $data = [])
    {
        $viewPath = $this->getViewPath($view);

        if (file_exists($viewPath)) {
            extract($data);
            require $viewPath;
        } else {
            // Handle view not found error
            http_response_code(500);
            echo "View not found: {$view}";
        }
    }

    private function getViewPath($view)
    {
        // Define the base view directory in a configuration file or constant
        $viewBasePath = __DIR__ . '/../../Views/';
        return $viewBasePath . $view . '.php';
    }
}
