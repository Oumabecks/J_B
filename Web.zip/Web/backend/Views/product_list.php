<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        .product-list {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .product-card {
            border: 1px solid #ddd;
            padding: 20px;
            width: 200px;
            text-align: center
        }
        .product-card img {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>Product List</h1>

    <?php 
    // Example product array
    $products = [
        [
            'name' => 'Product 1',
            'price' => 19.99,
            'image_url' => 'https://weka-directory-yako/product1.jpg'
        ],
        [
            'name' => 'Product 2',
            'price' => 29.99,
            'image_url' => 'https://weka-
            directory-yako/product2.jpg'
        ],
        // ongezea  products zingine unayo taka...
    ];

    if (!empty($products)): ?>
        <div class="product-list">
            <?php foreach ($products as $product): ?>
                <div class="product-card">
                    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <h2><?php echo htmlspecialchars($product['name']); ?></h2>
                    <p>$<?php echo number_format($product['price'], 2); ?></p>
                    <button>Add to Cart</button>
                </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <p>No products available.</p>
    <?php endif; ?>

</body>
</html>
