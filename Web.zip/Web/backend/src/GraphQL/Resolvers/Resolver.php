
<?php
// Define the Query type
$QueryType = new ObjectType([
    'name' => 'Query',
    'fields' => [
        'categories' => [
            'type' => Type::listOf($CategoryType),
            'resolve' => function ($root, $args) {
                try {
                    $connection = Database::getInstance();
                    if (!$connection) {
                        throw new Exception('Database connection failed');
                    }

                    $stmt = $connection->prepare("
                        SELECT c.name as category_name, p.*, g.*, pr.*, a.*
                        FROM categories c
                        LEFT JOIN products p ON c.id = p.category
                        LEFT JOIN gallery g ON p.id = g.id
                        LEFT JOIN prices pr ON p.id = pr.id
                        LEFT JOIN attributes a ON p.id = a.id
                    ");
                    $stmt->execute();
                    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if (!$rows) {
                        throw new Exception('No data found');
                    }
                    

                    $categories = [];
                    foreach ($rows as $row) {
                        $categoryName = $row['category_name'];
                        if (!isset($categories[$categoryName])) {
                            $categories[$categoryName] = [
                                'categories__name' => $categoryName,
                                'categories____typename' => 'Category',
                                'products' => [],
                            ];
                        }

                        $categories[$categoryName]['products'][] = [
                            'products__id' => $row['id'],
                            'products__name' => $row['name'],
                            'products__inStock' => (bool)$row['inStock'],
                            'products__gallery__001' => $row['products__gallery__001'],
                            'products__gallery__002' => $row['products__gallery__002'],
                            'products__gallery__003' => $row['products__gallery__003'],
                            'products__gallery__004' => $row['products__gallery__004'],
                            'products__gallery__005' => $row['products__gallery__005'],
                            'products__gallery__006' => $row['products__gallery__006'],
                            'products__gallery__007' => $row['products__gallery__007'],
                            'products__description' => $row['description'],
                            'products__category' => $row['category'],
                            'products__attributes__id' => [
                                [
                                    'products__attributes__id' => $row['attribute_id'],
                                    'products__attributes__name' => $row['attribute_name'],
                                    'products__attributes__type' => $row['attribute_type'],
                                    'products__attributes__items__id' => [
                                        [
                                            'products__attributes__items__displayValue' => $row['attribute_item_displayValue'],
                                            'products__attributes__items__value' => $row['attribute_item_value'],
                                            'products__attributes__items__id' => $row['attribute_item_id'],
                                            'products__attributes__items____typename' => 'AttributeItem',
                                        ],
                                    ],
                                    'products__attributes____typename' => 'Attribute',
                                ],
                            ],
                            'products__prices__amount' => [
                                [
                                    'products__prices__amount' => (float)$row['price_amount'],
                                    'products__prices__currency__label' => $row['currency_label'],
                                    'products__prices__currency__symbol' => $row['currency_symbol'],
                                    'products__prices__currency____typename' => 'Currency',
                                    'products__prices____typename' => 'Price',
                                ],
                            ],
                            'products__brand' => $row['brand'],
                            'products____typename' => 'Product',
                        ];
                    }

                    return array_values($categories);
                } catch (Exception $e) {
                    return ['error' => 'An error occurred: ' . $e->getMessage()];
                }
            },
        ],
    ],
]);
